"""Motor de análisis de carga — PF Jump Lab.
Procesa un export de Catapult (mismas columnas que el Control de Carga)
y calcula métricas de equipo, por jugador y ACWR (agudo:crónico)."""
import pandas as pd
import datetime

# Columnas clave del export de Catapult
COL = {
    "player": "Player Name", "period": "Period Name", "date": "Date",
    "activity": "Activity Name", "pos": "Position Name",
    "dist": "Total Distance", "mmin": "Metros recorridos por minuto jugado",
    "ad": "Accel&Decel Efforts", "hsd": "High Speed Distance",
    "sprint": "Sprint Efforts", "vmax": "Maximum Velocity",
    "load": "Total Player Load",
}

# Zonas de ACWR (acute:chronic workload ratio) — consenso de literatura
def acwr_zone(r):
    if r is None: return ("Sin histórico", "gray")
    if r < 0.80:  return ("Subcarga", "blue")
    if r <= 1.30: return ("Óptimo", "green")
    if r <= 1.50: return ("Precaución", "amber")
    return ("Riesgo alto", "red")

def excel_date(n):
    # Acepta Timestamp/datetime (export Catapult) o serial Excel.
    if hasattr(n, "date"):
        try: return n.date()
        except Exception: return None
    try:
        return datetime.date(1899, 12, 30) + datetime.timedelta(days=int(float(n)))
    except Exception:
        return None

def load_export(path_or_df):
    df = path_or_df if isinstance(path_or_df, pd.DataFrame) else pd.read_excel(path_or_df)
    df = df[df[COL["period"]] == "Session"].copy()          # totales por jugador
    df["_fecha"] = df[COL["date"]].apply(excel_date)
    df = df[df["_fecha"].notna()].copy()
    return df

def latest_session(df):
    """Identifica la sesión más reciente (la que 'acaba de terminar')."""
    last = max(d for d in df["_fecha"] if d is not None)
    return df[df["_fecha"] == last], last

def acwr_table(df, target_date, acute_days=7, chronic_days=28):
    """ACWR por jugador: carga aguda (7d) / carga crónica (28d) usando Player Load diario."""
    out = {}
    for player, g in df.groupby(COL["player"]):
        acute = g[(g["_fecha"] > target_date - datetime.timedelta(days=acute_days)) &
                  (g["_fecha"] <= target_date)][COL["load"]].sum() / acute_days
        chronic = g[(g["_fecha"] > target_date - datetime.timedelta(days=chronic_days)) &
                    (g["_fecha"] <= target_date)][COL["load"]].sum() / chronic_days
        out[player] = round(float(acute / chronic), 2) if chronic > 0 else None
    return out

def analyze(path_or_df):
    df = load_export(path_or_df)
    sess, fecha = latest_session(df)
    acwr = acwr_table(df, fecha)

    players = []
    for _, r in sess.iterrows():
        name = r[COL["player"]]
        ratio = acwr.get(name)
        zona, color = acwr_zone(ratio)
        players.append({
            "jugador": name, "posicion": r[COL["pos"]],
            "distancia": round(float(r[COL["dist"]]), 0),
            "m_min": round(float(r[COL["mmin"]]), 0),
            "player_load": round(float(r[COL["load"]]), 0),
            "hsr": round(float(r[COL["hsd"]]), 0),
            "sprints": int(r[COL["sprint"]]),
            "accel_decel": int(r[COL["ad"]]),
            "vmax": round(float(r[COL["vmax"]]), 1),
            "acwr": ratio, "zona": zona, "color": color,
        })
    players.sort(key=lambda x: x["player_load"], reverse=True)

    team = {
        "fecha": fecha.isoformat() if fecha else "",
        "sesion": sess[COL["activity"]].iloc[0] if len(sess) else "",
        "n_jugadores": len(players),
        "dist_prom": round(sess[COL["dist"]].mean(), 0),
        "load_prom": round(sess[COL["load"]].mean(), 0),
        "load_max": round(sess[COL["load"]].max(), 0),
        "hsr_prom": round(sess[COL["hsd"]].mean(), 0),
        "sprints_tot": int(sess[COL["sprint"]].sum()),
    }
    riesgo = [p for p in players if p["color"] in ("red", "amber")]
    sub = [p for p in players if p["color"] == "blue"]
    return {"team": team, "players": players, "riesgo": riesgo, "subcarga": sub}

if __name__ == "__main__":
    import json, sys
    res = analyze(sys.argv[1])
    print("SESIÓN:", res["team"]["sesion"], "| Fecha:", res["team"]["fecha"])
    print("Jugadores:", res["team"]["n_jugadores"], "| Load prom:", res["team"]["load_prom"])
    print("En riesgo/precaución:", [p["jugador"] for p in res["riesgo"]])
    print("Top 3 carga:", [(p["jugador"], p["player_load"], p["acwr"], p["zona"]) for p in res["players"][:3]])
